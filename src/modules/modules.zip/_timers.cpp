#include "timers.h"

#include <Arduino.h>

#if defined(ARDUINO_ARCH_AVR)
    #include <MemoryFree.h>
#elif defined(__arm__)
    extern "C" char* sbrk(int incr);
    static char top;
    int mTimers::freeMemory() {
        return &top - reinterpret_cast<char*>(sbrk(0));
    }
#elif defined(ARDUINO_ARCH_ESP8266) || defined(ARDUINO_ARCH_ESP32)
    int mTimers::freeMemory() { return ESP.getFreeHeap(); }
#else
    int mTimers::freeMemory() { return 0; }
#endif

int mTimers::noOfTasks = 0;
Scheduler mTimers::taskSheduler;
std::vector<mTimers::TimerCallback> mTimers::callbacks;
std::vector<mTimers::TaskCallbackData> mTimers::callbackDataList;

bool mTimers::add(long interval, const char* objectType, const char* objectId, TimerCallback callback) 
{
    Task* task = createTask(interval, objectType, objectId, callback);

    if (task != nullptr) {
        task->enable();
        noOfTasks++;

        return true;
    }

    return false;
}

bool mTimers::remove(const char* objectType, const char* objectId) 
{
    for (auto it = callbackDataList.begin(); it != callbackDataList.end(); ++it) {
        if (it->task != nullptr && strcmp(it->objectType, objectType) == 0 && strcmp(it->objectId, objectId) == 0) {
            it->task->disable();
            delete it->task;

            callbackDataList.erase(it);
            noOfTasks--;

            return true;
        }
    }

    return false;
}

void mTimers::clear()
{
    for (auto& cd : callbackDataList) {
        if (cd.task != nullptr) {
            cd.task->disable();
            delete cd.task;
        }
    }

    callbacks.clear();
    callbackDataList.clear();

    noOfTasks = 0;
}

void mTimers::clearByType(const char* objectType)
{
    for (auto it = callbackDataList.begin(); it != callbackDataList.end(); ++it) {
        if (it->task != nullptr && strcmp(it->objectType, objectType) == 0) {
            it->task->disable();
            delete it->task;

            callbackDataList.erase(it);
            noOfTasks--;
        }
    }
}

void mTimers::loop() {
    taskSheduler.execute();

    if (noOfTasks == 0) {
        freeMemory();
    }
}

Task* mTimers::createTask(long interval, const char* objectType, const char* objectId, TimerCallback callback)
{
    Task* task = nullptr;

    try {
        callbacks.push_back(callback);

        task = new Task(interval, TASK_FOREVER, onIteration, &taskSheduler, false, onEnable, onDisable, true);

        TaskCallbackData callbackData = { callback, task, objectType, objectId };
        callbackDataList.push_back(callbackData);        
        // callbackDataList.back().task = task;
    } catch (std::bad_alloc& e) {
        delete task;
        return nullptr;
    }

    return task;
}

void mTimers::onIteration()
{
    for (auto& cd : callbackDataList) {
        if (cd.task->isEnabled() && cd.callback) {
            cd.callback(cd.task, cd.objectType, cd.objectId);
        }
    }
}

bool mTimers::onEnable() 
{
    return true;
}

void mTimers::onDisable()
{
    noOfTasks--;
}