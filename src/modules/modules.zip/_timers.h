#ifndef __M_TIMERS_H__
#define __M_TIMERS_H__

#include <TaskSchedulerDeclarations.h>
#include "ReactESP.h"

#include <functional>
#include <vector>

class mTimers {
public:
    using TimerCallback = std::function<void(Task*, const char*, const char*)>;

private:
    static ReactESP app;

    struct TaskCallbackData {
        TimerCallback callback;
        Task* task;
        const char* objectType;
        const char* objectId;
    };

    static int noOfTasks;
    static Scheduler taskSheduler;
    static std::vector<TimerCallback> callbacks;
    static std::vector<TaskCallbackData> callbackDataList;
public:
    static bool add(long interval, const char* objectType, const char* objectId, TimerCallback callback);
    static bool remove(const char* objectType, const char* objectId);
    static void clear();
    static void clearByType(const char* objectType);

    static void loop();
private:
    static Task* createTask(long interval, const char* objectType, const char* objectId, TimerCallback callback);

    static void onIteration();
    static bool onEnable();
    static void onDisable();

    static int freeMemory();
};

#endif // __M_TIMERS_H__
